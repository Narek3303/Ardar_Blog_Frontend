import React, { useState, useRef, useEffect } from 'react';
import { Search, X } from 'react-feather';
import styled, { keyframes, css } from 'styled-components';
import PropTypes from 'prop-types';

// ======================
// ANIMATIONS
// ======================
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-5px); }
  to { opacity: 1; transform: translateY(0); }
`;

const pulse = keyframes`
  0% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.4); }
  70% { box-shadow: 0 0 0 10px rgba(59, 130, 246, 0); }
  100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0); }
`;

// ======================
// STYLED COMPONENTS
// ======================
const SearchContainer = styled.div`
  position: relative;
  width: 100%;
  max-width: 400px;
  margin: 0 auto;
  transition: all 0.3s ease;

  ${({ $focus }) => $focus && css`
    max-width: 450px;
  `}

  @media (max-width: 768px) {
    max-width: 100%;
  }
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 14px 52px 14px 48px;
  font-size: 16px;
  border: 2px solid #e5e7eb;
  border-radius: 50px;
  background: white;
  color: #1f2937;
  font-weight: 500;
  transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  appearance: none;
  outline: none;

  &::placeholder {
    color: #9ca3af;
    font-weight: 400;
  }

  &:hover {
    border-color: #d1d5db;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  }

  &:focus {
    border-color: #3b82f6;
    box-shadow: 0 6px 16px rgba(59, 130, 246, 0.2);
    animation: ${pulse} 2s infinite;
  }

  ${({ $hasValue }) => $hasValue && css`
    padding-right: 72px;
  `}
`;

const SearchIcon = styled(Search)`
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: #9ca3af;
  width: 20px;
  height: 20px;
  pointer-events: none;
  transition: all 0.3s ease;

  ${({ $focus }) => $focus && css`
    color: #3b82f6;
  `}
`;

const ClearButton = styled.button`
  position: absolute;
  right: 16px;
  top: 50%;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  color: #9ca3af;
  cursor: pointer;
  padding: 4px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  opacity: ${({ $visible }) => $visible ? 1 : 0};
  visibility: ${({ $visible }) => $visible ? 'visible' : 'hidden'};

  &:hover {
    color: #ef4444;
    background: rgba(239, 68, 68, 0.1);
  }

  svg {
    width: 18px;
    height: 18px;
  }
`;

const SearchSuggestions = styled.div`
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  right: 0;
  background: white;
  border-radius: 12px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
  z-index: 100;
  overflow: hidden;
  opacity: 0;
  transform: translateY(-10px);
  visibility: hidden;
  transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  max-height: 300px;
  overflow-y: auto;

  ${({ $visible }) => $visible && css`
    opacity: 1;
    transform: translateY(0);
    visibility: visible;
    animation: ${fadeIn} 0.3s ease-out;
  `}
`;

const SuggestionItem = styled.div`
  padding: 12px 20px;
  cursor: pointer;
  color: #4b5563;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 12px;

  &:hover {
    background: #f3f4f6;
    color: #1f2937;
  }

  &:active {
    background: #e5e7eb;
  }

  svg {
    width: 16px;
    height: 16px;
    color: #9ca3af;
  }
`;

// ======================
// COMPONENT
// ======================
const SearchBox = ({
                       value,
                       onChange,
                       placeholder = "Search products...",
                       suggestions = [],
                       onSuggestionSelect
                   }) => {
    const [isFocused, setIsFocused] = useState(false);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const inputRef = useRef(null);

    const handleClear = () => {
        onChange('');
        inputRef.current.focus();
    };

    const handleSuggestionClick = (suggestion) => {
        onChange(suggestion);
        if (onSuggestionSelect) onSuggestionSelect(suggestion);
        setShowSuggestions(false);
        inputRef.current.focus();
    };

    useEffect(() => {
        setShowSuggestions(isFocused && value.length > 0 && suggestions.length > 0);
    }, [isFocused, value, suggestions]);

    return (
        <SearchContainer $focus={isFocused}>
            <SearchInput
                ref={inputRef}
                type="text"
                placeholder={placeholder}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setTimeout(() => setIsFocused(false), 200)}
                $hasValue={value.length > 0}
                aria-label="Search products"
            />

            <SearchIcon $focus={isFocused} />

            <ClearButton
                onClick={handleClear}
                $visible={value.length > 0}
                aria-label="Clear search"
            >
                <X />
            </ClearButton>

            {suggestions.length > 0 && (
                <SearchSuggestions $visible={showSuggestions}>
                    {suggestions.map((suggestion, index) => (
                        <SuggestionItem
                            key={index}
                            onClick={() => handleSuggestionClick(suggestion)}
                            onMouseDown={(e) => e.preventDefault()} // Prevent input blur
                        >
                            <Search size={16} />
                            {suggestion}
                        </SuggestionItem>
                    ))}
                </SearchSuggestions>
            )}
        </SearchContainer>
    );
};

SearchBox.propTypes = {
    value: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired,
    placeholder: PropTypes.string,
    suggestions: PropTypes.arrayOf(PropTypes.string),
    onSuggestionSelect: PropTypes.func
};

SearchBox.defaultProps = {
    placeholder: "Search products...",
    suggestions: []
};

export default SearchBox;