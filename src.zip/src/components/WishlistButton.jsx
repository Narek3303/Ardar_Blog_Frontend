// src/components/WishlistButton.jsx
import React, { useState, useEffect, useRef } from 'react';
import axiosInstance from '../api/axiosInstance';
import { toast } from 'react-hot-toast';
import SizeSelectModal from './SizeSelectModal';
import styles from '../styles/WishlistButton.module.css';

const WishlistButton = ({ product, size = 'medium' }) => {
    const [liked, setLiked] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [selectedSizePrice, setSelectedSizePrice] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isAnimating, setIsAnimating] = useState(false);

    const buttonRef = useRef(null);
    const [ripple, setRipple] = useState({ x: 0, y: 0, size: 0 });
    const rippleTimeoutRef = useRef();

    // 1) При монтировании узнаём, вишлистнут ли продукт
    useEffect(() => {
        let cancelled = false;
        (async () => {
            try {
                // Եթե քեզ պետք է որոշակի ֆիլտրերով products բերել՝ կարող ես կամ
                // GET կամ POST անել, ինչպես նախորդում, օրինակ POST.
//      const resp = await axiosInstance.post('/shop/products/', { /*(filters)*/ });
                // Այստեղ օրինակ GET է՝ բոլոր products-ը ստանալու համար
                const resp = await axiosInstance.get('/shop/liked_products/');
                if (cancelled) return;

                // resp.data.products — զանգված product-ների,
                // որտեղ կան p.liked ֆլագներ
                // Նույն product.id համար ստանում ենք հենց liked արժեքը՝
                const me = resp.data.products.find(p => p.id === product.id);
                setLiked(Boolean(me?.liked));

                // Իսկ եթե ունես ամբողջ products–ի համար liked IDs–եր
                // const likedIds = resp.data.products
                //   .filter(p => p.liked)
                //   .map(p => p.id);
                // setLiked(likedIds.includes(product.id));

            } catch (err) {
                console.error('Products fetch failed:', err);
            }
        })();

        return () => {
            cancelled = true;
            clearTimeout(rippleTimeoutRef.current);
        };
    }, [product.id]);
    // Ripple effect
    const createRipple = e => {
        if (!buttonRef.current) return;
        const rect = buttonRef.current.getBoundingClientRect();
        const diameter = Math.max(rect.width, rect.height);
        setRipple({
            x: e.clientX - rect.left - diameter / 2,
            y: e.clientY - rect.top - diameter / 2,
            size: diameter,
        });
        clearTimeout(rippleTimeoutRef.current);
        rippleTimeoutRef.current = setTimeout(() => {
            setRipple({ x: 0, y: 0, size: 0 });
        }, 600);
    };

    // 2) Тогглим вишлист
    const toggleWishlist = async sizeId => {
        if (isLoading) return;
        setIsLoading(true);
        try {
            const payload = { product_id: product.id };
            if (sizeId) payload.size_id = sizeId;
            const { data } = await axiosInstance.post('/shop/wishlist/toggle/', payload);

            if (data.status === 'size_required') {
                setShowModal(true);
                toast.error('Please select a size');
            } else {
                setLiked(data.liked);
                setIsAnimating(true);
                toast[
                    data.liked ? 'success' : 'default'
                    ](
                    data.liked ? 'Added to wishlist' : 'Removed from wishlist',
                    { position: 'bottom-center' }
                );
                setTimeout(() => setIsAnimating(false), 800);
            }
        } catch (err) {
            console.error('Wishlist toggle error:', err);
            toast.error('An error occurred', { position: 'bottom-center' });
        } finally {
            setIsLoading(false);
        }
    };

    const handleHeartClick = e => {
        e.stopPropagation();
        createRipple(e);

        if (product.size_prices?.length) {
            // Если есть разные размеры — показываем модалку для выбора
            setShowModal(true);
        } else {
            toggleWishlist();
        }
    };

    const handleSizeSelect = (sizeId, price) => {
        setSelectedSizePrice({ id: sizeId, price });
        setShowModal(false);
        toggleWishlist(sizeId);
    };

    if (!product) {
        return (
            <div className={styles.skeletonLoader}>
                <div className={styles.skeletonPulse} />
            </div>
        );
    }

    return (
        <div className={`${styles.wishlistContainer} ${styles[size]}`}>
            <button
                ref={buttonRef}
                onClick={handleHeartClick}
                aria-label={liked ? 'Remove from wishlist' : 'Add to wishlist'}
                className={`
          ${styles.wishlistButton}
          ${liked ? styles.liked : styles.unliked}
          ${isLoading ? styles.loading : ''}
          ${isAnimating ? styles.animating : ''}
        `}
                disabled={isLoading}
            >
                {ripple.size > 0 && (
                    <span
                        className={styles.ripple}
                        style={{
                            left: ripple.x,
                            top: ripple.y,
                            width: ripple.size,
                            height: ripple.size,
                        }}
                    />
                )}

                <span className={styles.heartContainer}>
          {isLoading && (
              <span className={styles.spinner}>
              <svg viewBox="0 0 50 50">
                <circle cx="25" cy="25" r="20" />
              </svg>
            </span>
          )}
                    <span className={styles.heartBase}>
            <svg viewBox="0 0 24 24">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
                2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09
                C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5
                c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
            </svg>
          </span>
                    {isAnimating && (
                        <span className={styles.particles}>
              {[...Array(8)].map((_, i) => (
                  <span
                      key={i}
                      className={styles.particle}
                      style={{ animationDelay: `${i * 0.05}s` }}
                  />
              ))}
            </span>
                    )}
        </span>
            </button>

            {showModal && (
                <SizeSelectModal
                    product={product}
                    onSizeSelect={handleSizeSelect}
                    onClose={() => setShowModal(false)}
                    className={styles.modalOverlay}
                />
            )}
        </div>
    );
};

export default React.memo(WishlistButton);
